# -*- coding: utf-8 -*-
# Module: Library
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `Library` module"""

import unittest
import mock
from resources.lib.Library import Library

class LibraryTestCase(unittest.TestCase):
    pass
