service.subtitles.argenteam
==========================

argenteam.net subtitle service plugin for Kodi

Kodi 19 forked version of https://github.com/estemendoza/service.subtitles.argenteam 

For an easy end user install [go to my repo](https://github.com/guindous/repository.guindous)!
