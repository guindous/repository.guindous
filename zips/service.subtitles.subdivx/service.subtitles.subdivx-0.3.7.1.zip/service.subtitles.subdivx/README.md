service.subtitles.subdivx
=========================

Subdivx.com subtitle service plugin for XBMC/Kodi versions ranging
from Gotham (v13) up to Leia (v18). Ported from the pre-Gotham
version. All the credit to its authors.
